#include <iostream>
#include <chrono>
using namespace std;
using namespace chrono;

class Time {
private:
    int h, m;

public:
    Time(int hh, int mm) : h(hh), m(mm) {}

    friend int minutesBetween(const Time& a, const Time& b);
    friend bool earlier(const Time& a, const Time& b);
};

inline int minutesBetween(const Time& a, const Time& b) {
    int first = a.h * 60 + a.m;
    int second = b.h * 60 + b.m;
    return (first > second) ? first - second : second - first;
}

inline bool earlier(const Time& a, const Time& b) {
    if (a.h != b.h) return a.h < b.h;
    return a.m < b.m;
}

// Comparable small function without the inline keyword.
int ordinaryAdd(int a, int b) {
    return a + b;
}

inline int inlineAdd(int a, int b) {
    return a + b;
}

int main() {
    Time departure(9, 45), arrival(13, 10);
    cout << "Minutes between: " << minutesBetween(departure, arrival) << '\n';
    cout << boolalpha << "Arrival earlier than departure: "
         << earlier(arrival, departure) << '\n';

    Time beforeNoon(11, 50), afterNoon(12, 10);
    Time sameTime(12, 10);
    cout << "Before noon earlier than after noon: "
         << earlier(beforeNoon, afterNoon) << '\n';
    cout << "Same time difference: "
         << minutesBetween(sameTime, afterNoon) << '\n';

    // Basic timing experiment. Run separately with -O0 and -O2.
    constexpr int ITERATIONS = 10000000;
    volatile long long sink = 0;

    auto start1 = steady_clock::now();
    for (int i = 0; i < ITERATIONS; ++i)
        sink = sink + ordinaryAdd(i, 1);
    auto end1 = steady_clock::now();

    auto start2 = steady_clock::now();
    for (int i = 0; i < ITERATIONS; ++i)
        sink = sink + inlineAdd(i, 1);
    auto end2 = steady_clock::now();

    cout << "Ordinary function time (ms): "
         << duration<double, milli>(end1 - start1).count() << '\n';
    cout << "Inline function time (ms): "
         << duration<double, milli>(end2 - start2).count() << '\n';
    cout << "Timing guard: " << sink << '\n';

    return 0;
}
