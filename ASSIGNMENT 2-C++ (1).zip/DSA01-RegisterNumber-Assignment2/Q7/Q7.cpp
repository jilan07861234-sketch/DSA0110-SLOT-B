#include <iostream>
using namespace std;

const int K = 5;

// Original design: shift all retained entries when the array is full.
class ShiftingHistory {
private:
    int data[K];
    int count = 0;
public:
    int moves = 0;

    void add(int value) {
        if (count < K) {
            data[count++] = value;
        } else {
            for (int i = 1; i < K; ++i) {
                data[i - 1] = data[i];
                ++moves;
            }
            data[K - 1] = value;
        }
    }

    void print() const {
        for (int i = 0; i < count; ++i) cout << data[i] << ' ';
        cout << '\n';
    }
};

// Redesigned version: circular buffer overwrites the oldest entry in O(1).
class CircularHistory {
private:
    int data[K];
    int count = 0;
    int next = 0;
public:
    int writes = 0;

    void add(int value) {
        data[next] = value;
        ++writes;
        next = (next + 1) % K;
        if (count < K) ++count;
    }

    void printOldestToNewest() const {
        int start = (count == K) ? next : 0;
        for (int i = 0; i < count; ++i)
            cout << data[(start + i) % K] << ' ';
        cout << '\n';
    }
};

int main() {
    ShiftingHistory original;
    CircularHistory redesigned;

    // Identical test sequence for both designs.
    for (int value = 10; value <= 100; value += 10) {
        original.add(value);
        redesigned.add(value);
    }

    cout << "Original shifting design (last five): ";
    original.print();
    cout << "Redesigned circular design (last five): ";
    redesigned.printOldestToNewest();

    cout << "Elements shifted by original design: "
         << original.moves << '\n';
    cout << "Writes by circular design: "
         << redesigned.writes << '\n';

    cout << "\nDiagnosis: shifting requires O(K) moves when full.\n";
    cout << "Redesign: circular buffer inserts in O(1) time.\n";
    cout << "Both use O(K) storage and preserve the same last-five values.\n";
    return 0;
}
