#include <iostream>
#include <string>
using namespace std;

struct Parcel {
    double weightKg;
    bool express;
    bool insured;
};

// Integer weight is interpreted as grams.
double charge(int weightGrams, bool express = false, bool insured = false) {
    double kg = weightGrams / 1000.0;
    double amount = kg * 50.0;
    if (express) amount += 30.0;
    if (insured) amount += 20.0;
    cout << "Selected overload: grams\n";
    return amount;
}

// Floating-point weight is interpreted as kilograms.
double charge(double weightKg, bool express = false, bool insured = false) {
    double amount = weightKg * 50.0;
    if (express) amount += 30.0;
    if (insured) amount += 20.0;
    cout << "Selected overload: kilograms\n";
    return amount;
}

// Parcel overload.
double charge(const Parcel& parcel) {
    double amount = parcel.weightKg * 50.0;
    if (parcel.express) amount += 30.0;
    if (parcel.insured) amount += 20.0;
    cout << "Selected overload: Parcel object\n";
    return amount;
}

int main() {
    Parcel p{2.5, true, false};

    cout << "Call 1: charge(2) = Rs. " << charge(2) << "\n\n";
    cout << "Call 2: charge(2.0f) = Rs. " << charge(2.0f) << "\n\n";
    cout << "Call 3: charge(2.0) = Rs. " << charge(2.0) << "\n\n";
    cout << "Call 4: charge(500, true) = Rs. " << charge(500, true) << "\n\n";
    cout << "Call 5: charge(1.5, true, true) = Rs. "
         << charge(1.5, true, true) << "\n\n";
    cout << "Call 6: charge(p) = Rs. " << charge(p) << '\n';

    return 0;
}
