#include <iostream>
#include <vector>
using namespace std;

// Returns a reference to the largest element in a valid, non-empty array.
int& highestMark(int marks[], int size) {
    int highestIndex = 0;
    for (int i = 1; i < size; ++i) {
        if (marks[i] > marks[highestIndex]) {
            highestIndex = i;
        }
    }
    return marks[highestIndex];
}

// Read-only alternative: caller cannot modify the returned element through this reference.
const int& highestMarkReadOnly(const int marks[], int size) {
    int highestIndex = 0;
    for (int i = 1; i < size; ++i) {
        if (marks[i] > marks[highestIndex]) {
            highestIndex = i;
        }
    }
    return marks[highestIndex];
}

// DANGEROUS EXAMPLE -- defined only to demonstrate the compiler diagnostic.
// Never call this function: its returned reference dangles after the function returns.
int& dangerousLocalReference() {
    int localValue = 50;
    return localValue; // Expected warning with g++ -Wall -Wextra.
}

int highestMarkIndex(const int marks[], int size) {
    int index = 0;
    for (int i = 1; i < size; ++i) {
        if (marks[i] > marks[index]) index = i;
    }
    return index;
}

int main() {
    int marks[] = {76, 91, 84, 88, 95, 73};
    int size = sizeof(marks) / sizeof(marks[0]);

    cout << "Original highest mark: " << highestMark(marks, size) << '\n';

    // A function returning int& can be used on the left side of assignment.
    highestMark(marks, size) += 2;
    cout << "After moderation (+2): " << highestMark(marks, size) << '\n';

    cout << "Read-only highest mark: " << highestMarkReadOnly(marks, size) << '\n';

    int index = highestMarkIndex(marks, size);
    cout << "Index-based access: marks[" << index << "] = " << marks[index] << '\n';

    // Vector growth may reallocate storage and invalidate old references/pointers.
    vector<int> dynamicMarks = {70, 80, 90};
    int& oldReference = dynamicMarks[2];
    cout << "Before vector growth: " << oldReference << '\n';
    dynamicMarks.reserve(100); // May reallocate; oldReference must not be used now.
    cout << "After vector growth, safely access again: " << dynamicMarks[2] << '\n';

    return 0;
}
