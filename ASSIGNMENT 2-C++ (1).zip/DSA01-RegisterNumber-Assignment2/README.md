# C++ Assignment 2 – CO2

**Repository:** `DSA01-RegisterNumber-Assignment2`  
**Student name:** Replace with your name  
**Register number:** Replace with your register number  
**Course:** C++ Programming – CO2

## Compiler
- Compiler: GNU g++
- Standard: C++17
- Check version: `g++ --version`

## Compile and run
From the relevant task folder:

```bash
g++ -std=c++17 -Wall -Wextra Q1.cpp -o Q1
./Q1
```

On Windows Command Prompt, run `Q1.exe` instead of `./Q1`.

Repeat with the matching source and executable names for Q2–Q7.

## Task summaries
- **Q1:** Demonstrates call by value, reference, pointer, return by reference, and default arguments.
- **Q2:** Demonstrates returning references to array elements, read-only references, index alternatives, and vector reallocation safety. The dangling-reference example is commented out because using it is undefined behaviour.
- **Q3:** Demonstrates default arguments and overload resolution for grams, kilograms, and a Parcel object.
- **Q4:** Implements a SavingsAccount class with a private fixed-size transaction array and a mini-statement.
- **Q5:** Implements shared static ticket counting, seat allocation, and a waiting list.
- **Q6:** Implements friend functions for time comparison and a simple inline/non-inline timing experiment.
- **Q7:** Compares a shifting history array with a circular-buffer redesign.

## Evidence to add
For every task:
1. Write your prediction before running any output-prediction program.
2. Compile using the command above and resolve warnings/errors.
3. Run the program and save a screenshot in that task's `Output` folder.
4. Record test inputs, actual output, and interpretation in your report.
5. Commit each task separately.

## Suggested commit sequence
```bash
git add Q1
git commit -m "Complete Q1 call mechanisms"
git add Q2
git commit -m "Complete Q2 return by reference"
git add Q3
git commit -m "Complete Q3 overloads and defaults"
git add Q4
git commit -m "Complete Q4 savings account class"
git add Q5
git commit -m "Complete Q5 static bus tickets"
git add Q6
git commit -m "Complete Q6 friend and inline functions"
git add Q7
git commit -m "Complete Q7 redesign validation"
git add README.md
git commit -m "Add assignment README"
```

**Important:** Replace the placeholders, execute and verify every program yourself, and include genuine screenshots and your own measured timings. Do not claim an execution or measurement until you have performed it.
