#include <iostream>
#include <string>
using namespace std;

class BusTicket {
private:
    static int issued;
    static const int CAPACITY = 3;
    int seat;
    string name;

public:
    explicit BusTicket(const string& passengerName)
        : seat(0), name(passengerName) {
        if (issued < CAPACITY) {
            ++issued;
            seat = issued;
        }
    }

    static int count() {
        return issued;
    }

    void print() const {
        cout << name << ": ";
        if (seat != 0) cout << "Seat " << seat;
        else cout << "Waiting";
        cout << '\n';
    }
};

// Definition of the static data member outside the class.
int BusTicket::issued = 0;

void createMoreTickets() {
    BusTicket localTickets[2] = {
        BusTicket("Esha"), BusTicket("Farhan")
    };
    for (const BusTicket& ticket : localTickets) ticket.print();
    cout << "Issued inside function: " << BusTicket::count() << '\n';
}

int main() {
    cout << "Main ticket array:\n";
    BusTicket trip[4] = {
        BusTicket("Asha"), BusTicket("Bala"),
        BusTicket("Chitra"), BusTicket("Dev")
    };

    for (const BusTicket& ticket : trip) ticket.print();
    cout << "Issued: " << BusTicket::count() << "\n\n";

    cout << "Create tickets inside a function (first call):\n";
    createMoreTickets();

    cout << "\nCreate tickets inside the same function (second call):\n";
    createMoreTickets();

    cout << "\nFinal shared issued count: " << BusTicket::count() << '\n';
    return 0;
}
