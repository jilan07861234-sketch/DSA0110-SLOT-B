#include <iostream>
using namespace std;

// Call by value: only the local copy changes.
void concessionByValue(double fee, int percent) {
    fee -= fee * percent / 100.0;
    cout << "Inside value function: " << fee << '\n';
}

// Call by reference: the caller's variable changes.
void concessionByReference(double& fee, int percent) {
    fee -= fee * percent / 100.0;
}

// Call by pointer: the caller's variable changes through its address.
void concessionByPointer(double* fee, int percent) {
    if (fee != nullptr) {
        *fee -= *fee * percent / 100.0;
    }
}

// Return-by-reference demonstration from the question.
int& bigger(int& p, int& q) {
    return (p > q) ? p : q;
}

void show(int x, int y = 5, int z = 10) {
    cout << x + y + z << ' ';
}

void applyByValue(long long fee, int percent) {
    fee -= fee * percent / 100; // changes only the local copy
}

void applyConcession(long long& fee, int percent) {
    fee -= fee * percent / 100;
}

int main() {
    cout << "PART A: HOSTEL CONCESSION\n";
    double valueFee = 45000, referenceFee = 45000, pointerFee = 45000;

    concessionByValue(valueFee, 10);
    concessionByReference(referenceFee, 10);
    concessionByPointer(&pointerFee, 10);

    cout << "Stored fee after value     : " << valueFee << '\n';
    cout << "Stored fee after reference : " << referenceFee << '\n';
    cout << "Stored fee after pointer   : " << pointerFee << "\n\n";

    cout << "PART B: COMPLETE THE CODE\n";
    long long hostelFee = 45000;
    applyByValue(hostelFee, 10);
    cout << "after call by value : " << hostelFee << '\n';
    applyConcession(hostelFee, 10);
    cout << "after call by reference: " << hostelFee << "\n\n";

    cout << "PART C: OUTPUT-PREDICTION PROGRAM\n";
    int a = 1, b = 2, c = 3;
    auto change = [](int x, int& y, int* z) {
        x += 10;
        y += 10;
        *z += 10;
    };
    change(a, b, &c);
    cout << a << ' ' << b << ' ' << c << '\n';

    bigger(a, c) = 100;
    cout << a << ' ' << c << '\n';

    show(1);
    show(1, 2);
    show(1, 2, 3);
    cout << '\n';

    cout << "\nBoundary checks: fee 0 and 100% concession\n";
    double zeroFee = 0;
    concessionByReference(zeroFee, 100);
    cout << "Zero fee remains: " << zeroFee << '\n';
    return 0;
}
