#include <iostream>
#include <string>
using namespace std;

class SavingsAccount {
private:
    string accountNumber;
    double balance;
    double transactions[10];
    int count;

    void recordTransaction(double amount) {
        if (count < 10) {
            transactions[count++] = amount;
        } else {
            // Shift left: discard the oldest transaction.
            for (int i = 1; i < 10; ++i) {
                transactions[i - 1] = transactions[i];
            }
            transactions[9] = amount;
        }
    }

public:
    explicit SavingsAccount(const string& number, double openingBalance)
        : accountNumber(number), balance(openingBalance), count(0) {}

    void deposit(double amount) {
        if (amount <= 0) {
            cout << "Invalid deposit amount\n";
            return;
        }
        balance += amount;
        recordTransaction(amount);
    }

    void withdraw(double amount) {
        if (amount <= 0 || amount > balance) {
            cout << "Invalid withdrawal amount\n";
            return;
        }
        balance -= amount;
        recordTransaction(-amount);
    }

    void miniStatement() const {
        cout << "\nMini statement for account " << accountNumber << '\n';
        cout << "Balance: Rs. " << balance << '\n';
        cout << "Last " << count << " transactions:\n";
        for (int i = 0; i < count; ++i) {
            if (transactions[i] >= 0)
                cout << "Deposit : Rs. " << transactions[i] << '\n';
            else
                cout << "Withdraw: Rs. " << -transactions[i] << '\n';
        }
    }
};

int main() {
    SavingsAccount account("SA1001", 5000);

    // More than 10 transactions: the oldest entries are discarded.
    for (int i = 1; i <= 8; ++i) {
        account.deposit(i * 100);
    }
    account.withdraw(250);
    account.deposit(900);
    account.deposit(1100);
    account.withdraw(300);

    account.miniStatement();
    return 0;
}
